<?php

namespace App\Http\Controllers;

use App\Models\ObatBatch;
use App\Models\ObatSatuan;
use App\Models\Penerimaan;
use App\Services\StokService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PenerimaanController extends Controller
{
    /**
     * POST /api/penerimaan
     *
     * Body:
     * {
     *   "supplier_id": 1, "nama_supplier": "PT Kimia Farma Trading",
     *   "no_faktur": "KF-2026-0088",
     *   "tanggal_terima": "2026-08-29",
     *   "tanggal_jatuh_tempo": "2026-09-29",
     *   "tempo_label": "1_bulan",
     *   "is_pkp": true,
     *   "diskon_faktur_rp": 0,
     *   "diskon_faktur_persen": 2,
     *   "items": [
     *     {
     *       "obat_id": 1, "obat_satuan_id": 3, "qty": 5,
     *       "harga_beli": 46000, "diskon": 0,
     *       "nomor_batch": "PCM-0230", "tanggal_exp": "2028-01-01"
     *     }
     *   ]
     * }
     */
    public static function ensureDatabaseColumns(): void
    {
        try {
            if (!\Illuminate\Support\Facades\Schema::hasColumn('penerimaan_item', 'kemasan')) {
                \Illuminate\Support\Facades\Schema::table('penerimaan_item', function ($table) {
                    $table->unsignedInteger('kemasan')->nullable()->after('qty');
                });
            }
            if (!\Illuminate\Support\Facades\Schema::hasColumn('penerimaan_item', 'harga_beli_sebelumnya')) {
                \Illuminate\Support\Facades\Schema::table('penerimaan_item', function ($table) {
                    $table->decimal('harga_beli_sebelumnya', 15, 2)->nullable();
                });
            }
            if (!\Illuminate\Support\Facades\Schema::hasColumn('penerimaan_item', 'harga_jual_saat_itu')) {
                \Illuminate\Support\Facades\Schema::table('penerimaan_item', function ($table) {
                    $table->decimal('harga_jual_saat_itu', 15, 2)->nullable();
                });
            }
            if (!\Illuminate\Support\Facades\Schema::hasColumn('penerimaan_item', 'margin_persen')) {
                \Illuminate\Support\Facades\Schema::table('penerimaan_item', function ($table) {
                    $table->decimal('margin_persen', 6, 2)->nullable();
                });
            }
            if (!\Illuminate\Support\Facades\Schema::hasColumn('penerimaan', 'petugas_bayar')) {
                \Illuminate\Support\Facades\Schema::table('penerimaan', function ($table) {
                    $table->string('petugas_bayar', 100)->nullable()->after('status_bayar');
                });
            }
            if (!\Illuminate\Support\Facades\Schema::hasColumn('penerimaan', 'tanggal_bayar')) {
                \Illuminate\Support\Facades\Schema::table('penerimaan', function ($table) {
                    $table->date('tanggal_bayar')->nullable()->after('status_bayar');
                });
            }
            if (!\Illuminate\Support\Facades\Schema::hasColumn('obat_batch', 'qty_masuk')) {
                \Illuminate\Support\Facades\Schema::table('obat_batch', function ($table) {
                    $table->integer('qty_masuk')->default(0);
                });
            }
            if (!\Illuminate\Support\Facades\Schema::hasColumn('obat_batch', 'tanggal_masuk')) {
                \Illuminate\Support\Facades\Schema::table('obat_batch', function ($table) {
                    $table->date('tanggal_masuk')->nullable();
                });
            }
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('ensureDatabaseColumns warning: ' . $e->getMessage());
        }
    }

    public function store(Request $r, StokService $stok)
    {
        self::ensureDatabaseColumns();

        $data = $r->validate([
            'supplier_id' => 'nullable|exists:suppliers,id',
            'nama_supplier' => 'required|string|max:255',
            'no_faktur' => 'required|string|max:60',
            'tanggal_terima' => 'required|date',
            'tanggal_jatuh_tempo' => 'nullable|date',
            'tempo_label' => 'nullable|in:1_bulan,2_bulan,3_bulan,6_bulan,1_tahun,custom',
            'is_pkp' => 'boolean',
            'diskon_faktur_rp' => 'nullable|numeric|min:0',
            'diskon_faktur_persen' => 'nullable|numeric|min:0|max:100',
            'items' => 'required|array|min:1',
            'items.*.obat_id' => 'required|exists:obat,id',
            'items.*.obat_satuan_id' => 'required|exists:obat_satuan,id',
            'items.*.qty' => 'required|numeric|min:0.01',
            'items.*.kemasan' => 'nullable|numeric|min:0.01',
            'items.*.harga_beli' => 'required|numeric|min:0',
            'items.*.diskon' => 'nullable|numeric|min:0',
            'items.*.nomor_batch' => 'nullable|string|max:50',
            'items.*.tanggal_exp' => 'nullable|date',
        ]);

        try {
            return DB::transaction(function () use ($data, $r, $stok) {
                $subtotal = 0;
                $itemsSiap = [];

                foreach ($data['items'] as $it) {
                    $satuan = ObatSatuan::with('obat')->findOrFail($it['obat_satuan_id']);
                    $obat = $satuan->obat;
                    $diskonItem = $it['diskon'] ?? 0;
                    $subtotalItem = $it['qty'] * $it['harga_beli'] - $diskonItem;
                    $subtotal += $subtotalItem;

                    $hargaBeliSebelumnya = $satuan->harga_beli;
                    $hargaJualBaru = isset($it['harga_jual_baru']) && $it['harga_jual_baru'] > 0
                        ? (float) $it['harga_jual_baru']
                        : (float) $satuan->harga_jual;
                    $marginPersen = $hargaJualBaru > 0
                        ? round((($hargaJualBaru - $it['harga_beli']) / $hargaJualBaru) * 100, 2)
                        : null;

                    $kemasan = isset($it['kemasan']) && $it['kemasan'] > 0
                        ? (float) $it['kemasan']
                        : (float) ($satuan->faktor ?: 1);

                    $itemsSiap[] = [
                        'obat_id' => $obat->id,
                        'obat_satuan_id' => $satuan->id,
                        'nama_obat' => $obat->nama,
                        'nama_satuan' => $satuan->nama_satuan,
                        'faktor' => $satuan->faktor,
                        'qty' => $it['qty'],
                        'kemasan' => $kemasan,
                        'harga_beli' => $it['harga_beli'],
                        'diskon' => $diskonItem,
                        'subtotal' => $subtotalItem,
                        'nomor_batch' => $it['nomor_batch'] ?? null,
                        'tanggal_exp' => $it['tanggal_exp'] ?? null,
                        'harga_beli_sebelumnya' => $hargaBeliSebelumnya,
                        'harga_jual_saat_itu' => $hargaJualBaru,
                        'margin_persen' => $marginPersen,
                    ];
                }

                $diskonRp = $data['diskon_faktur_rp'] ?? 0;
                $diskonPersen = $data['diskon_faktur_persen'] ?? 0;
                $diskonTotal = $diskonRp + round($subtotal * $diskonPersen / 100);
                $subtotalSetelahDiskon = max($subtotal - $diskonTotal, 0);

                $isPkp = $data['is_pkp'] ?? false;
                $persenPpn = 11;
                $ppn = $isPkp ? round($subtotalSetelahDiskon * $persenPpn / 100) : 0;
                $total = $subtotalSetelahDiskon + $ppn;

                $userId = $r->user()?->id ?? auth('sanctum')->id() ?? auth()->id();
                if (!$userId) {
                    $firstUser = \App\Models\User::first();
                    $userId = $firstUser ? $firstUser->id : 1;
                }

                $penerimaan = \App\Models\Penerimaan::create([
                    'supplier_id' => $data['supplier_id'] ?? null,
                    'nama_supplier' => $data['nama_supplier'],
                    'no_faktur' => $data['no_faktur'],
                    'tanggal_terima' => $data['tanggal_terima'],
                    'tanggal_jatuh_tempo' => $data['tanggal_jatuh_tempo'] ?? null,
                    'tempo_label' => $data['tempo_label'] ?? 'custom',
                    'is_pkp' => $isPkp,
                    'persen_ppn' => $persenPpn,
                    'subtotal' => $subtotal,
                    'diskon_faktur_rp' => $diskonRp,
                    'diskon_faktur_persen' => $diskonPersen,
                    'subtotal_setelah_diskon' => $subtotalSetelahDiskon,
                    'dpp' => $subtotalSetelahDiskon,
                    'ppn' => $ppn,
                    'total' => $total,
                    'status_bayar' => 'belum',
                    'user_id' => $userId,
                ]);

                foreach ($itemsSiap as $item) {
                    $penerimaan->items()->create($item);

                    $isiKemasan = isset($item['kemasan']) && $item['kemasan'] > 0
                        ? (float) $item['kemasan']
                        : (float) ($item['faktor'] ?: 1);

                    $stokMasuk = (int) round($item['qty'] * $isiKemasan);

                    $stok->ubah(
                        $item['obat_id'],
                        $stokMasuk,
                        'masuk',
                        'penerimaan',
                        $penerimaan->id
                    );

                    $hargaBeliPerUnitMasuk = ($isiKemasan > 0)
                        ? round($item['harga_beli'] / $isiKemasan)
                        : $item['harga_beli'];

                    $updateSatuan = [
                        'harga_beli' => $hargaBeliPerUnitMasuk,
                        'harga_beli_sebelumnya' => $item['harga_beli_sebelumnya'],
                    ];
                    if (!empty($item['harga_jual_saat_itu']) && $item['harga_jual_saat_itu'] > 0) {
                        $updateSatuan['harga_jual'] = $item['harga_jual_saat_itu'];
                    }

                    ObatSatuan::where('id', $item['obat_satuan_id'])->update($updateSatuan);

                    if ($item['nomor_batch']) {
                        \App\Models\Obat::where('id', $item['obat_id'])->update([
                            'nomor_batch' => $item['nomor_batch'],
                            'tanggal_exp' => $item['tanggal_exp'],
                        ]);

                        ObatBatch::updateOrCreate(
                            ['obat_id' => $item['obat_id'], 'nomor_batch' => $item['nomor_batch']],
                            [
                                'tanggal_exp' => $item['tanggal_exp'],
                                'qty_masuk' => $stokMasuk,
                                'tanggal_masuk' => $data['tanggal_terima'],
                            ]
                        );
                    }
                }

                return response()->json($penerimaan->load('items'), 201);
            });
        } catch (\Illuminate\Validation\ValidationException $ve) {
            throw $ve;
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('Penerimaan store error: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
            return response()->json([
                'message' => 'Gagal menyimpan penerimaan: ' . $e->getMessage(),
            ], 500);
        }
    }

    /** GET /api/penerimaan — untuk halaman Riwayat Penerimaan */
    public function index(Request $r)
    {
        $q = Penerimaan::query();

        if ($r->filled('search')) {
            $search = trim($r->search);
            $q->where(function ($query) use ($search) {
                $query->where('no_faktur', 'like', "%{$search}%")
                    ->orWhere('nama_supplier', 'like', "%{$search}%")
                    ->orWhereHas('items', function ($itemQ) use ($search) {
                        $itemQ->where('nama_obat', 'like', "%{$search}%")
                            ->orWhere('nomor_batch', 'like', "%{$search}%");
                    });
            });
        }

        if ($r->filled('dari_tanggal') && $r->filled('sampai_tanggal')) {
            $q->whereBetween('tanggal_terima', [$r->dari_tanggal, $r->sampai_tanggal]);
        } elseif ($r->filled('dari_tanggal')) {
            $q->whereDate('tanggal_terima', '>=', $r->dari_tanggal);
        } elseif ($r->filled('sampai_tanggal')) {
            $q->whereDate('tanggal_terima', '<=', $r->sampai_tanggal);
        } elseif ($r->filled('periode')) {
            match ($r->periode) {
                'hari-ini' => $q->whereDate('tanggal_terima', now()->toDateString()),
                'minggu-ini' => $q->whereBetween('tanggal_terima', [now()->startOfWeek(), now()->endOfWeek()]),
                'bulan-ini' => $q->whereMonth('tanggal_terima', now()->month)->whereYear('tanggal_terima', now()->year),
                'bulan-lalu' => $q->whereMonth('tanggal_terima', now()->subMonth()->month)
                                  ->whereYear('tanggal_terima', now()->subMonth()->year),
                default => null,
            };
        }

        if ($r->filled('nama_supplier') && $r->nama_supplier !== 'semua') {
            $q->where('nama_supplier', $r->nama_supplier);
        }

        if ($r->filled('status_bayar') && in_array($r->status_bayar, ['belum', 'lunas'])) {
            $q->where('status_bayar', $r->status_bayar);
        }

        if ($r->filled('user_id') && $r->user_id !== 'semua') {
            $q->where('user_id', $r->user_id);
        }

        return $q->withCount('items')->with(['items', 'user:id,nama,username,role'])->orderByDesc('tanggal_terima')->orderByDesc('id')->limit(1000)->get();
    }

    /** GET /api/penerimaan/{id} — detail lengkap untuk modal Riwayat */
    public function show(Penerimaan $penerimaan)
    {
        return $penerimaan->load(['items', 'user:id,nama,username,role']);
    }

    /** PUT /api/penerimaan/{penerimaan}/toggle-bayar — update status bayar, tgl bayar manual, dan nama petugas bayar manual */
    public function toggleBayar(Request $r, Penerimaan $penerimaan)
    {
        self::ensureDatabaseColumns();

        $statusBaru = $r->input('status_bayar');
        if (!$statusBaru) {
            $statusBaru = $penerimaan->status_bayar === 'lunas' ? 'belum' : 'lunas';
        }

        $tanggalBayar = $r->has('tanggal_bayar')
            ? ($r->input('tanggal_bayar') ?: null)
            : ($statusBaru === 'lunas' ? ($penerimaan->tanggal_bayar ?: now()->toDateString()) : null);

        $defaultPetugas = $r->user() ? ($r->user()->nama ?: $r->user()->username) : 'Petugas';
        $petugasBayar = $r->has('petugas_bayar')
            ? $r->input('petugas_bayar')
            : ($penerimaan->petugas_bayar ?: ($statusBaru === 'lunas' ? $defaultPetugas : null));

        $updateData = [
            'status_bayar' => $statusBaru,
            'tanggal_bayar' => $tanggalBayar,
        ];

        if (\Illuminate\Support\Facades\Schema::hasColumn('penerimaan', 'petugas_bayar')) {
            $updateData['petugas_bayar'] = $petugasBayar;
        }

        $penerimaan->update($updateData);

        return response()->json([
            'message' => "Faktur {$penerimaan->no_faktur} ditandai " . ($statusBaru === 'lunas' ? 'LUNAS (Sudah Dibayar)' : 'BELUM LUNAS'),
            'penerimaan' => $penerimaan->fresh()->load('items'),
        ]);
    }

    /** PUT /api/penerimaan/{penerimaan} — edit faktur penerimaan (nama PBF, no faktur, tanggal, harga beli, qty) */
    public function update(Request $r, Penerimaan $penerimaan, StokService $stok)
    {
        self::ensureDatabaseColumns();

        $data = $r->validate([
            'nama_supplier' => 'required|string|max:255',
            'supplier_id' => 'nullable|exists:suppliers,id',
            'no_faktur' => 'required|string|max:60',
            'tanggal_terima' => 'required|date',
            'tanggal_jatuh_tempo' => 'nullable|date',
            'tempo_label' => 'nullable|in:1_bulan,2_bulan,3_bulan,6_bulan,1_tahun,custom',
            'is_pkp' => 'boolean',
            'diskon_faktur_rp' => 'nullable|numeric|min:0',
            'diskon_faktur_persen' => 'nullable|numeric|min:0|max:100',
            'update_master_pbf' => 'nullable|boolean',
            'items' => 'nullable|array',
            'items.*.id' => 'nullable|integer',
            'items.*.qty' => 'nullable|numeric|min:0.01',
            'items.*.harga_beli' => 'nullable|numeric|min:0',
            'items.*.diskon' => 'nullable|numeric|min:0',
            'items.*.nomor_batch' => 'nullable|string|max:50',
            'items.*.tanggal_exp' => 'nullable|date',
        ]);

        return DB::transaction(function () use ($data, $r, $penerimaan, $stok) {
            $namaSupplierBaru = trim($data['nama_supplier']);
            $namaSupplierLama = $penerimaan->nama_supplier;

            // Jika ada permintaan update master supplier / PBF
            if (!empty($data['update_master_pbf'])) {
                if ($penerimaan->supplier_id) {
                    \App\Models\Supplier::where('id', $penerimaan->supplier_id)
                        ->update(['nama' => $namaSupplierBaru]);
                } else {
                    \App\Models\Supplier::where('nama', $namaSupplierLama)
                        ->update(['nama' => $namaSupplierBaru]);
                }
                // Sinkronkan seluruh penerimaan dengan nama PBF lama
                \App\Models\Penerimaan::where('nama_supplier', $namaSupplierLama)
                    ->update(['nama_supplier' => $namaSupplierBaru]);
            }

            // Update item-item jika disertakan
            if (!empty($data['items'])) {
                foreach ($data['items'] as $itemData) {
                    if (empty($itemData['id'])) continue;
                    $item = \App\Models\PenerimaanItem::where('id', $itemData['id'])
                        ->where('penerimaan_id', $penerimaan->id)
                        ->first();
                    if (!$item) continue;

                    $qtyLama = (float) $item->qty;
                    $qtyBaru = isset($itemData['qty']) ? (float) $itemData['qty'] : $qtyLama;
                    $hargaBeliBaru = isset($itemData['harga_beli']) ? (float) $itemData['harga_beli'] : (float) $item->harga_beli;
                    $diskonBaru = isset($itemData['diskon']) ? (float) $itemData['diskon'] : (float) $item->diskon;
                    $subtotalBaru = max(($qtyBaru * $hargaBeliBaru) - $diskonBaru, 0);

                    // Jika kuantitas berubah, sesuaikan stok masuk
                    if ($qtyBaru != $qtyLama) {
                        $isiKemasan = isset($item->kemasan) && $item->kemasan > 0
                            ? (float) $item->kemasan
                            : (float) ($item->faktor ?: 1);

                        $selisihQty = (int) round(($qtyBaru - $qtyLama) * $isiKemasan);
                        if ($selisihQty != 0) {
                            $stok->ubah(
                                $item->obat_id,
                                $selisihQty,
                                'penyesuaian',
                                'penerimaan',
                                $penerimaan->id,
                                "Koreksi qty penerimaan faktur {$data['no_faktur']}"
                            );
                        }
                    }

                    // Update satuan harga beli jika harga berubah
                    if ($hargaBeliBaru != $item->harga_beli && $item->obat_satuan_id) {
                        $isiKemasan = isset($item->kemasan) && $item->kemasan > 0 ? (float) $item->kemasan : 1;
                        $hargaPerUnit = $isiKemasan > 1 ? round($hargaBeliBaru / $isiKemasan, 2) : $hargaBeliBaru;
                        \App\Models\ObatSatuan::where('id', $item->obat_satuan_id)
                            ->update(['harga_beli' => $hargaPerUnit]);
                    }

                    // Update batch info jika berubah
                    $updateBatch = [];
                    if (isset($itemData['nomor_batch'])) $updateBatch['nomor_batch'] = $itemData['nomor_batch'];
                    if (isset($itemData['tanggal_exp'])) $updateBatch['tanggal_exp'] = $itemData['tanggal_exp'];

                    $item->update(array_merge([
                        'qty' => $qtyBaru,
                        'harga_beli' => $hargaBeliBaru,
                        'diskon' => $diskonBaru,
                        'subtotal' => $subtotalBaru,
                    ], $updateBatch));

                    if (!empty($itemData['nomor_batch'])) {
                        \App\Models\ObatBatch::where('obat_id', $item->obat_id)
                            ->where('nomor_batch', $item->nomor_batch)
                            ->update([
                                'nomor_batch' => $itemData['nomor_batch'],
                                'tanggal_exp' => $itemData['tanggal_exp'] ?? $item->tanggal_exp,
                            ]);
                    }
                }
            }

            // Hitung ulang akumulasi subtotal dari seluruh item penerimaan
            $subtotalSemua = (float) $penerimaan->items()->sum('subtotal');
            $diskonRp = isset($data['diskon_faktur_rp']) ? (float) $data['diskon_faktur_rp'] : (float) $penerimaan->diskon_faktur_rp;
            $diskonPersen = isset($data['diskon_faktur_persen']) ? (float) $data['diskon_faktur_persen'] : (float) $penerimaan->diskon_faktur_persen;
            $diskonTotal = $diskonRp + round($subtotalSemua * $diskonPersen / 100);
            $subtotalSetelahDiskon = max($subtotalSemua - $diskonTotal, 0);

            $isPkp = isset($data['is_pkp']) ? (bool) $data['is_pkp'] : (bool) $penerimaan->is_pkp;
            $persenPpn = 11;
            $ppn = $isPkp ? round($subtotalSetelahDiskon * $persenPpn / 100) : 0;
            $total = $subtotalSetelahDiskon + $ppn;

            $penerimaan->update([
                'nama_supplier' => $namaSupplierBaru,
                'supplier_id' => $data['supplier_id'] ?? $penerimaan->supplier_id,
                'no_faktur' => $data['no_faktur'],
                'tanggal_terima' => $data['tanggal_terima'],
                'tanggal_jatuh_tempo' => $data['tanggal_jatuh_tempo'] ?? $penerimaan->tanggal_jatuh_tempo,
                'tempo_label' => $data['tempo_label'] ?? $penerimaan->tempo_label,
                'is_pkp' => $isPkp,
                'persen_ppn' => $persenPpn,
                'subtotal' => $subtotalSemua,
                'diskon_faktur_rp' => $diskonRp,
                'diskon_faktur_persen' => $diskonPersen,
                'subtotal_setelah_diskon' => $subtotalSetelahDiskon,
                'dpp' => $subtotalSetelahDiskon,
                'ppn' => $ppn,
                'total' => $total,
            ]);

            return response()->json($penerimaan->fresh()->load('items'));
        });
    }

    /** DELETE /api/penerimaan/{penerimaan} — hapus faktur penerimaan yang salah input */
    public function destroy(Penerimaan $penerimaan, StokService $stok)
    {
        return DB::transaction(function () use ($penerimaan, $stok) {
            foreach ($penerimaan->items as $item) {
                $isiKemasan = isset($item->kemasan) && $item->kemasan > 0 ? (float) $item->kemasan : (float) ($item->faktor ?: 1);
                $stokDitarik = -(int) round($item->qty * $isiKemasan);
                try {
                    $stok->ubah(
                        $item->obat_id,
                        $stokDitarik,
                        'retur',
                        'penerimaan',
                        $penerimaan->id,
                        "Hapus / Pembatalan faktur penerimaan {$penerimaan->no_faktur}"
                    );
                } catch (\Exception $e) {
                    \App\Models\Obat::where('id', $item->obat_id)->update(['stok' => 0]);
                }
                $item->delete();
            }
            $penerimaan->delete();
            return response()->noContent();
        });
    }
}
