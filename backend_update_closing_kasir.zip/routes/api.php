<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\ObatController;
use App\Http\Controllers\ObatReferensiController;
use App\Http\Controllers\PenerimaanController;
use App\Http\Controllers\PembayaranOnlineController;
use App\Http\Controllers\PenjualanController;
use App\Http\Controllers\TokoController;
use App\Http\Controllers\StokMutasiController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\PengeluaranController;
use App\Http\Controllers\DuitkuController;
use Illuminate\Support\Facades\Route;

// Publik
Route::get('/obat', [ObatController::class, 'index']);
Route::get('/obat/{obat}', [ObatController::class, 'show']);
Route::get('/suppliers', [SupplierController::class, 'index']);
Route::get('/obat-referensi', [ObatReferensiController::class, 'index']);
Route::get('/pengaturan-margin', [ObatController::class, 'getPengaturanMargin']);

Route::get('/storage/{path}', function ($path) {
    if (\Illuminate\Support\Facades\Storage::disk('public')->exists($path)) {
        $file = \Illuminate\Support\Facades\Storage::disk('public')->get($path);
        $mime = \Illuminate\Support\Facades\Storage::disk('public')->mimeType($path);
        return response($file, 200)->header('Content-Type', $mime);
    }
    abort(404);
})->where('path', '.*');

// Toko online
Route::get('/toko/status-operasional', [TokoController::class, 'statusOperasional']);
Route::post('/toko/checkout', [TokoController::class, 'checkout']);

// Duitku payment gateway
Route::post('/duitku/create/{kodeTracking}', [DuitkuController::class, 'createInvoice']);
Route::post('/duitku/callback', [DuitkuController::class, 'callback']);

// Tracking pesanan
Route::get('/pesanan-cari', [TokoController::class, 'cari']);
Route::get('/pesanan/{kode_tracking}', [TokoController::class, 'showByTracking']);
Route::get('/pesanan/{kode_tracking}/status', [TokoController::class, 'statusByTracking']);
Route::post('/pesanan/{kode_tracking}/bukti', [TokoController::class, 'uploadBuktiByTracking']);
Route::post('/pesanan/{kode_tracking}/batal', [TokoController::class, 'batalkanByTracking']);

Route::post('/login', [AuthController::class, 'login']);

Route::get('/debug-last-seen', function (\Illuminate\Http\Request $r) {
    if ($r->query('kunci') !== 'bima2026') {
        abort(403, 'Akses ditolak.');
    }
    \App\Http\Controllers\UserController::ensureLastSeenColumn();
    $cols = \Illuminate\Support\Facades\DB::select("SHOW COLUMNS FROM users LIKE 'last_seen_at'");
    $users = \Illuminate\Support\Facades\DB::table('users')
        ->select('id', 'nama', 'username', 'role', 'aktif', 'last_seen_at')
        ->get();
    return response()->json([
        'server_time' => now()->toIso8601String(),
        'has_last_seen_column' => !empty($cols),
        'users' => $users,
    ]);
});

Route::get('/sync-okt-2026', function (\Illuminate\Http\Request $r) {
    if ($r->query('kunci') !== 'bima2026') {
        abort(403, 'Akses ditolak.');
    }
    ini_set('max_execution_time', 300);
    $seeder = new \Database\Seeders\UpdateObatOktSeeder();
    return response()->json($seeder->run());
});

// Autentikasi
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/user/ping', [UserController::class, 'ping']);
    Route::post('/user/closing', [UserController::class, 'closing']);
    Route::post('/ganti-password', [AuthController::class, 'gantiPassword']);

    // Audit log
    Route::post('/audit-logs', [AuditLogController::class, 'store']);
    Route::middleware('role:admin')->group(function () {
        Route::get('/audit-logs', [AuditLogController::class, 'index']);
        Route::delete('/audit-logs', [AuditLogController::class, 'destroyAll']);
    });

    // Kasir & admin
    Route::middleware('role:admin,kasir')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'index']);
        Route::get('/kpi', [DashboardController::class, 'kpi']);
        Route::get('/obat/{obat}/batches', [ObatController::class, 'getBatches']);
        Route::get('/obat/{obat}/riwayat-pengadaan', [ObatController::class, 'riwayatPengadaan']);
        Route::post('/obat/opname', [ObatController::class, 'opname']);
        Route::get('/stok-mutasi', [StokMutasiController::class, 'index']);
        Route::get('/users', [UserController::class, 'index']);
        Route::post('/suppliers', [SupplierController::class, 'store']);
        Route::delete('/suppliers/{supplier}', [SupplierController::class, 'destroy']);
        Route::post('/penerimaan', [PenerimaanController::class, 'store']);
        Route::get('/penerimaan', [PenerimaanController::class, 'index']);
        Route::get('/penerimaan/{penerimaan}', [PenerimaanController::class, 'show']);
        Route::put('/penerimaan/{penerimaan}/toggle-bayar', [PenerimaanController::class, 'toggleBayar']);
        Route::post('/obat/perbaiki-margin-semua', [ObatController::class, 'perbaikiMarginSemua']);
        Route::post('/obat', [ObatController::class, 'store']);
        Route::put('/obat/{obat}', [ObatController::class, 'update']);
        Route::delete('/obat/{obat}', [ObatController::class, 'destroy']);
        Route::delete('/obat/{obat}/satuan/{satuan}', [ObatController::class, 'hapusSatuan']);
        Route::get('/obat-sampah', [ObatController::class, 'sampah']);
        Route::post('/obat/{id}/pulihkan', [ObatController::class, 'pulihkan']);
        Route::delete('/obat/{id}/permanen', [ObatController::class, 'hapusPermanen']);
        Route::post('/penjualan', [PenjualanController::class, 'store']);
        Route::get('/penjualan', [PenjualanController::class, 'index']);
        Route::get('/penjualan/{penjualan}', [PenjualanController::class, 'show']);
        Route::get('/pembayaran-online', [PembayaranOnlineController::class, 'index']);
        Route::get('/pembayaran-online/counter', [PembayaranOnlineController::class, 'counter']);
        Route::post('/pembayaran-online/{pembayaran}/tandai-selesai', [PembayaranOnlineController::class, 'tandaiSelesai']);
        Route::post('/pembayaran-online/{pembayaran}/konfirmasi', [PembayaranOnlineController::class, 'konfirmasi']);
        Route::post('/pembayaran-online/{pembayaran}/kurang-bayar', [PembayaranOnlineController::class, 'kurangBayar']);
        Route::post('/pembayaran-online/{pembayaran}/tolak', [PembayaranOnlineController::class, 'tolak']);
        Route::get('/pesanan-online', [PembayaranOnlineController::class, 'index']);
        Route::post('/pesanan-online/{pembayaran}/verifikasi', [PembayaranOnlineController::class, 'konfirmasi']);
    });

    // Khusus admin
    Route::middleware('role:admin')->group(function () {
        Route::get('/laporan', [LaporanController::class, 'index']);
        Route::get('/pengeluaran', [PengeluaranController::class, 'index']);
        Route::post('/pengeluaran', [PengeluaranController::class, 'store']);
        Route::delete('/pengeluaran/{id}', [PengeluaranController::class, 'destroy']);
        Route::delete('/pembayaran-online/bersihkan-semua', [PembayaranOnlineController::class, 'bersihkanSemuaPesananOnline']);
        Route::delete('/pembayaran-online/{pembayaran}', [PembayaranOnlineController::class, 'destroy']);
        Route::get('/users/kelola', [UserController::class, 'kelola']);
        Route::post('/users', [UserController::class, 'store']);
        Route::put('/users/{user}', [UserController::class, 'update']);
        Route::delete('/users/{user}', [UserController::class, 'destroy']);
        Route::post('/pengaturan-margin', [ObatController::class, 'setPengaturanMargin']);
        Route::get('/pengaturan-operasional', [UserController::class, 'getPengaturanOperasional']);
        Route::post('/pengaturan-operasional', [UserController::class, 'setPengaturanOperasional']);
    });
});
