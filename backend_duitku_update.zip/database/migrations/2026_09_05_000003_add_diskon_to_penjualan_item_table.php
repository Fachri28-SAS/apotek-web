<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('penjualan_item', function (Blueprint $table) {
            if (!Schema::hasColumn('penjualan_item', 'diskon')) {
                $table->decimal('diskon', 15, 2)->default(0)->after('tuslah');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('penjualan_item', function (Blueprint $table) {
            if (Schema::hasColumn('penjualan_item', 'diskon')) {
                $table->dropColumn('diskon');
            }
        });
    }
};
